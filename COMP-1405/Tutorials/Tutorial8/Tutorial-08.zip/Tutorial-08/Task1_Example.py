#Imran Juma
#SN: 101036672 
#Tutorial 7
#Task 1 

two_dimentional_list = [[1,2,3],[4,5,6],[7,8,9]]

#Part 1
print(two_dimentional_list)

print("-------")

#Part 2 
for row in two_dimentional_list:
	print(row)

print("-------")

#Part 3
for row in two_dimentional_list:
	for val in row:
		print(val)

