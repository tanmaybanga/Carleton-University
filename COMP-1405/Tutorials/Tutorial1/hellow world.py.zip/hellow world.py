print ("hello world")
