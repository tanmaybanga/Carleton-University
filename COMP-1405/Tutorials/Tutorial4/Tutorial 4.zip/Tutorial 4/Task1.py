
FirstName = input("Please Enter Your First Name ")

StudentNumber = input("Please Enter Your Student Number ")

UserUnput = int(input("What was the grade percentage you recived "))

if UserUnput >= 90: 
	print ("You Recived A Grade Of A+")

elif UserUnput >= 85:  
	print ("You Recived A Grade Of A")

elif UserUnput >= 80:
	print ("You Recived A Grade Of A-")

elif UserUnput >= 77:
	print ("You Recived A Grade Of B+")

elif UserUnput >= 73:
	print ("You Recived A Grade Of B")

elif UserUnput >= 70:
	print ("You Recived A Grade Of B-")

elif UserUnput >= 67:
	print ("You Recived A Grade Of C+")

elif UserUnput >= 63:
	print ("You Recived A Grade Of C")

elif UserUnput >= 60:
	print ("You Recived A Grade Of C-")

elif UserUnput >= 57:
	print ("You Recived A Grade Of D")

elif UserUnput >= 53:
	print ("You Recived A Grade Of D")

elif UserUnput >= 50:
	print ("You Recived A Grade Of D-")

else:
	print ("You Recived A failing Grade")





