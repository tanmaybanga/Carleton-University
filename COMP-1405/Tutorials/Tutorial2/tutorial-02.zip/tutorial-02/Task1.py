# This Will Save Our Input Varibles 
FirstName = input("Please Enter Your First Name ")
LastName = input("Please Enter Your Last Name ")

#This Will Be The Printed Messages
print("Your Name Is")

#This Is Outputing Our First Name and Last Name That We Entered 
print(FirstName, LastName)

#This Will Convcert Our Name to a string in Hexidecimal Format 
print(hex(id (FirstName)))
print(hex(id (LastName)))

