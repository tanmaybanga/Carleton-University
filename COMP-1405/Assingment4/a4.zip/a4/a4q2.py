#--------------------------------------
#Assingment 4 Project 2
#Asssingment Completed By Imran Gabrani Juma
# SN:101036672
#Completed for Dr. Robert Collier
#Quiz, Mutiple Choice // True and False
#--------------------------------------


#--------------------------------------
#Book Citation:
    #Giddis, T. (2014) Starting Our With Python (Third Edditon). (pp 1-615)

#Website Citation

#Tutorial Citation
#--------------------------------------


#The Topics of Todays Quiz Will Pertain To Apple, and Apple Products 10 Multiple Choice and 5 True and False
#5 True and False Questions & 10 Multiple Choice Questions 

#                                                               Program Begins 


#--------------------------------------
#The Following Lines Presented Here Will Produce Our Test Bank As Our Multiple Choice Questions
Question1 = [1, 0, ['JetBlack','Rose Gold','Orange'], -1,  'Apples Newest iPhone Colour Is']
Question2 = [2, 0, ['Space grey','Orange','Gold'], -1, 'What is the Newest Colour Of the Macbook Pro']
Question3 = [3, 0, ['Touch Bar','OLED Keyboard','No Screen'] -1,  'What Is The New Feature Included With The MacBook Pro']
Question4 = [4, 0, ['32GB','64GB','128GB'], -1,  'What Is The Base Model Storage Size For The iPad Pro 12.9 Inch']
Question5 = [5, 0, ['4K','5K','1080P'], -1,  'Apple iPhone 6S and 7 Can Shoot In What Video Format']
Question6 = [6, 1, ['38&44mm','38&42MM','40&22MM'], -1,  'What Two Sizes Does The Apple Watch Come In']
Question7 = [7, 2, ['22%27Inch','27 and 32 Inch','21 and 27 Inch'], -1,  'What Two Screen Sizes Does The iMac Come in']
Question8 = [8, 0, ['Glossy Black','Silver','Dark Blue'], -1,  'What Colour is the Mac Pro Computer']
Question9 = [9, 0, ['Gold','Standard Silver','Space Grey'], -1,  'What Colour Is The 2016 Macbook Pro Not Avalible In']
Question10 = [10, 0, ['500GB','1TB','256GB'], -1, 'What Is The Storage Capacity in A iMac 21 Inch']
#--------------------------------------


#--------------------------------------
#Here Are The Correct Answers For The True And False

#1 JetBlack
#2 Space Grey
#3 Touch Bar
#4 32GB
#5 4K Resolution
#6 38MM ad 42MM
#7 21" and 27" 
#8 Glossy Black
#9 Gols
#10 500GB
#--------------------------------------


#--------------------------------------
#The Following Lines Presented Here Will Produce Our Test Bank As True And False Questions 
TrueFalse1 = [1, True, -1,  'The Apple Pencil Only Works With Thhe iPad Pro?']
TrueFalse2 = [2, True, -1, 'Apple Makes Uses A Linuz Based Operating System?']
TrueFalse3 = [3, True, -1, 'You Must Have An iPhone To Use an Apple Watch']
TrueFalse4 = [4, True, -1, 'Apple Processors are made By Samsung']
TrueFalse5 = [5, True, -1, 'The iPhone 5S Is the newest iPhone']
#--------------------------------------


#--------------------------------------
#Here Are The Correct Answers For The True And False
#1 True
#2 True
#3 True 
#4 True
#5 True
#--------------------------------------


#--------------------------------------
#This Line Will Produce The Following QUestions We Created and Definiting Them

The_Multiple_Choice = 
[
Question1,
Question2,
Question3,
Question4,
Question5,
Question6,
Question7,
Question8,
Question9,
Question10
]

The_True_And_False = 
[
TrueFalse1,
TrueFalse2,
TrueFalse3,
TrueFalse4,
TrueFalse5
]

#--------------------------------------

#--------------------------------------
#This Function Would Have Pulled Our Muliple Choice Questions
def Mulitple_Choice_Terminal(The_Questions):
#--------------------------------------

#--------------------------------------
#This Function Would Have Pulled Our True and False Questions
def The_True_And_False_Terminal(The_Questions):
#--------------------------------------

#--------------------------------------
#This would have been our main generating the program and Running The Tally Along With THe Score
def main():

#Returning Main Function
main()
#--------------------------------------

#                                                               Program Ends 

