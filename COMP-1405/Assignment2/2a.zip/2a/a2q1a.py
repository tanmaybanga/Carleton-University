#Imran Juma 101036672
#Assignment 2
#Question 1 Part 1
#Guess Who Win Only Version
#-----------------------------------------------------------------------Citations-----------------------------------------------------------------------#

#Book Citation: 
	#Giddis, T. (2014) Starting Our With Python (Third Edditon). (pp 1-615)

#Website Citation

#Tutorial Citation 

#----------------------------------------------------------------------Program Begins-------------------------------------------------------------------------#

#This Print's the Welcome Staement For The User
print ("\n")
print ("Welcome To Imran's Guess Who Game Round 1!")
print ("**First Letter Of The Answer Must Be Capital**")
print ("\n")

#Prints The Question
Selection = input("Does Your Character Have A Pipe?\n")

#The Only Logical Responce
if Selection == ("Yes"):
	print ("Congradulations, You Have Won The Game \n")

#----------------------------------------------------------------------Program Ends-------------------------------------------------------------------------#
