#Imran Juma 101036672
#Assignment 2
#Question 1 Part 2
#Guess Who Goes to "No" Statement
#-----------------------------------------------------------------------Citations-----------------------------------------------------------------------#

#Book Citation: 
	#Giddis, T. (2014) Starting Our With Python (Third Edditon). (pp 1-615)

#Website Citation

#Tutorial Citation 

#----------------------------------------------------------------------Program Begins-------------------------------------------------------------------------#
#This Will Print My Introduction Statement 
#This Will Also Print The Skip A Line Function 
print ("\n")
print ("Welcome To Imran's Guess Who Round 2!")
print ("**First Letter Of The Answer Must Be Capital**")
print ("\n")

#This Will Print Out The Question
Selection = input("Does Your Character Have a scar Yes Or No?\n")

#User Responce If Captial Y
if Selection == ("Yes"):
	print ("Try Again\n")

#Question Goes Directly to else statement
else:
	print ("Correct, None of the face options have scars")
	print ("\n")

#----------------------------------------------------------------------Program Ends-------------------------------------------------------------------------#