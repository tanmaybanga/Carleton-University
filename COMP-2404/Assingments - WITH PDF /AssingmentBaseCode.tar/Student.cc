#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Student.h"

Student::Student(int i)
{
  id = i;
  numCourses = 0;

  for (int i=0; i<MAX_NUM_COURSES; ++i) {
    courses[i].setCode(0);
    courses[i].setGrade(0);
  }
}

void Student::setId(int i)
{
  id = i;
}

void Student::setNumCourses(int n)
{
  numCourses = n;
}

void Student::setCourse(int index, int code, int grade)
{
  courses[index].setCode(code);
  courses[index].setGrade(grade);
}

void Student::print()
{
  cout<< endl << "Id: " << id << endl;

  for (int i=0; i<numCourses; ++i)
    courses[i].print();
}

